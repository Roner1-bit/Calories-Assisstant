import 'package:gym_system/models/user_model/user_model.dart';

import '../../models/user_model/food_model.dart';

String adminUserName="admin";

String password="Zxc102030";

const String domain="@gmail.com";

List<FoodModel> foodObjects = [];

List<String> foodNames = [];

List<FoodModel> eatenFood = [];

late UserModel userModel;